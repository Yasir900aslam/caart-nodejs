## Steps to run
we use cx_freeze to create binary of the above program, 
first we need to install requirements

we can do this by
``pip3 install -r requirements.txt
``
to the shell in the root folder
then we are able to build the program using 
``python setup.py build``

At the end of the execution, a dist folder will be createed, zip it, rename it ``caartclient``
and move it to caart django server, 