import sys
from cx_Freeze import setup, Executable

options = {"build_exe": {"includes": ["atexit", "Data\\audit.csv", "Data\\policies.txt", "Data\\sercurityoptions.txt"]}}

executables = [Executable("caart.py", base=None)]

setup(
    name="caart",
    version="0.1",
    description="caart auditing and reemediation",
    options=options,
    executables=executables,
)