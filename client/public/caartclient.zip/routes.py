#  app.post("/v1/client/login", Client.Login());  |||  const { client_email, client_password } = req.body;
# app.post("/v1/rem/add", Remediations.addRemediationInAUser()); ||| const { email, remediation_name, Status, isapplied } = req.body;
# app.post("/v1/audit/add", Audits.addAuditInAUser()); ||| (const { email, policy, status } = req.body;)